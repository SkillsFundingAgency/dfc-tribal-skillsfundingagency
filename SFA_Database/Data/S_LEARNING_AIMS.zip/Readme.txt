LC

This CSV is a static file that should be included with the nightly CSV exports in support of the legacy search system.

The uncompressed CSV file may directly be offered for download.  We are using a static file as contents change rarely and the effort to support this from the new system simply to support the legacy search system would be considerable.

The LARs data contained in the CSV was created from the latest LARS dataset available on the 26/11/2014.